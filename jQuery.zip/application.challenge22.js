//Challenge 5 (DOM Ready)
//application.js 
$(document).ready(function() {
 $("span").text("$100");
});
